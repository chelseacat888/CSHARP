﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tip__Tax__and_Total
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            decimal foodCharge; //food charge variable
            decimal tip; // tip variable
            decimal tax; // tax variable
            decimal total; // total variable

            // get the food charge

            foodCharge = decimal.Parse(foodChargeTextBox.Text);

            // get the tip

            tip = foodCharge * 0.15m;

            // get the taxes

            tax = foodCharge * 0.07m;

            // get the total

            total = foodCharge + tip + tax;

            // display tip amount

            tipAmountLabel.Text = tip.ToString("c");


            // display tax amount

            taxLabel.Text = tax.ToString("c");

            // display total

            totalLabel.Text = total.ToString("c");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
